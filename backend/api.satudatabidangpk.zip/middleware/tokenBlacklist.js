const tokenBlacklist = [];

module.exports = tokenBlacklist;
